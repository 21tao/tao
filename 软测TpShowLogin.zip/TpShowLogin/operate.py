from login_page import LoginPage


class LoginHandle:
    # 操作层
    def __init__(self):
        self.login_page = LoginPage()

    # 实现操作方法,分别是用户名，密码，验证码，登陆按钮
    def input_username(self, username):
        self.login_page.find_username().send_keys(username)

    def input_password(self, pwd):
        self.login_page.find_password().send_keys(pwd)

    def input_verify_code(self, code):
        self.login_page.find_verify_code().send_keys(code)

    def click_login_btn(self):
        self.login_page.find_login_btn().click()
