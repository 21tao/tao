from selenium import webdriver


class DriverUtil:
    _driver = None

    # 打开浏览器，进入网站
    @classmethod
    def get_driver(cls):
        if cls._driver is None:
            cls._driver = webdriver.Chrome()
            cls._driver.get('http://hmshop-test.itheima.net/')
            cls._driver.implicitly_wait(3)
            cls._driver.maximize_window()

        return cls._driver

    # 退出网站
    @classmethod
    def quit_driver(cls):
        cls._driver.quit()
        cls._driver = None


# 获取弹出框的提示消息
#     :return: 消息文本内容
def get_msg():

    msg = DriverUtil.get_driver().find_element_by_class_name('layui-layer-content').text
    return msg
