from selenium.webdriver.common.by import By
from Utils import DriverUtil


class LoginPage:
    # 对象层
    def __init__(self):
        self.driver = DriverUtil.get_driver()

        # 用户名
        self.username = (By.ID, 'username')
        # 密码
        self.password = (By.ID, "password")
        # 验证码
        self.verify_code = (By.ID, "verify_code")
        # 登陆按钮
        self.login_btn = (By.NAME, "sbtbutton")

    # 定义操作方法,分别是用户名，密码，验证码，登陆按钮
    def find_username(self):
        return self.driver.find_element(*self.username)

    def find_password(self):
        return self.driver.find_element(*self.password)

    def find_verify_code(self):
        return self.driver.find_element(*self.verify_code)

    def find_login_btn(self):
        return self.driver.find_element(*self.login_btn)
