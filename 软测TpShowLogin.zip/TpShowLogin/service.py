from operate import LoginHandle


class LoginProxy:
    # 业务层

    def __init__(self):
        self.login_handle = LoginHandle()

    # 实现真正业务
    def login(self, username, password, code):
        self.login_handle.input_username(username)
        self.login_handle.input_password(password)
        self.login_handle.input_verify_code(code)
        self.login_handle.click_login_btn()
