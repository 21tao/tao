import json
import time
import unittest
from selenium import webdriver
from parameterized import parameterized

import Utils
from Utils import DriverUtil
from service import LoginProxy


# 获取数据并存储
def build_data():
    test_data = []
    with open('./data.json', encoding='UTF-8') as f:
        json_data = json.load(f)
        for login_data in json_data.values():
            test_data.append((
                login_data.get("username"),
                login_data.get("password"),
                login_data.get("code"),
                login_data.get("is_success"),
                login_data.get('expect')
            ))
        print("test_data", test_data)
        return test_data


class TestLogin(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        # 获取驱动
        cls.driver = DriverUtil.get_driver()
        # 获取业务
        cls.login_proxy = LoginProxy()

    @classmethod
    def tearDownClass(cls):
        # 关闭驱动
        DriverUtil.quit_driver()
        # cls.driver.quit()

    # 因为只是打开一次浏览器，setUp作为一个重复操作
    def setUp(self):
        #         进入首页，点击登陆连接
        time.sleep(1)
        self.driver.get("http://hmshop-test.itheima.net/")

        # self.driver.get("http://hmshop-test.itheima.net/Home/user/login.html")
        self.driver.find_element_by_link_text("登录").click()

    # def setDown(self):
    #     self.driver.find_element_by_link_text('安全退出').click()

    # 加载数据驱动
    @parameterized.expand(build_data)
    def test_add(self, username, password, code, is_success, expect):
        print("username={} password={} code={} is_success={} expect={}".format(
            username, password, code, is_success, expect
        ))

        #         登陆
        self.login_proxy.login(username, password, code)
        # 验证arg1是arg2的子串，不是则fail
        if is_success:
            # 验证登陆后是否为该用户名，判断真正登陆成功了嘛
            self.assertIn(expect, self.driver.find_element_by_link_text('3133825137@').text)
        else:
            #             获取提示消息
            msg = Utils.get_msg()
            print("msg=", msg)
            self.assertIn(expect, msg)


if __name__ == '__main__':
    unittest.main()
