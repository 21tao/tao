import requests
import json
import threading
from queue import Queue


class HeiMaTouTiao:
    def __init__(self):
        self.headers = {
            'User_Agent':
                'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 '
                'Safari/537.36 '
        }

        #   url队列
        self.url_queue = Queue()
        #   内容队列
        self.content_queue = Queue()

    # 获取表格数据文件
    def get_url_list(self, star_page, end_page):
        url_list = []
        # 营销短信服务表格文件
        for i in range(star_page, end_page + 1):
            url_temp = f'http://jxd.itheima.net/manage/marketing/page?current={i}&size=15&status=0'
            url_list.append(url_temp)
        # 添加到url队列
        for url in url_list:
            self.url_queue.put(url)

    # 解析提取文件
    def get_data(self):
        content_li = []
        while True:
            # 拿到url队列的url
            url = self.url_queue.get()
            # 请求并拿文本数据
            comment = requests.get(url=url, headers=self.headers)
            data = json.loads(comment.text)
            # print(data)
            # 拿到data下标为records
            data = data['data']['records']
            # print(data)
            for index in range(len(data)):
                content = dict()
                content['主题'] = data[index]['title']
                content['创建时间'] = data[index]['createTime']
                content['短信内容'] = data[index]['contentText']
                content['申请人'] = data[index]['createUserName']
                content_li.append(content)
            # 添加到内容队列
            self.content_queue.put(content_li)
            # 告知url队列已完成该线程
            self.url_queue.task_done()

    # 保存数据
    def save_data(self):
        while True:
            content_list = self.content_queue.get()
            with open('toutiao.json', mode='a+', encoding='utf-8') as f:
                # 转为json
                f.write(json.dumps(content_list, ensure_ascii=False, indent=2))
            # 告知内容队列已完成该线程
            self.content_queue.task_done()

    def run(self):
        start_page = int(input('开始'))
        end_page = int(input('结束'))
        t_list = []
        if start_page <= 0:
            print('应从第1页开始')
        else:
            # 启动线程
            t_url = threading.Thread(target=self.get_url_list, args=(start_page, end_page))
            t_list.append(t_url)
            # 提取内容线程
            for i in range(9):
                t_content = threading.Thread(target=self.get_data)
                t_list.append(t_content)
            # 保存内容线程
            t_save = threading.Thread(target=self.save_data)
            t_list.append(t_save)
            for t in t_list:
                t.start()
            for q in (self.url_queue, self.content_queue):
                q.join()


if __name__ == '__main__':
    heimaitaotiao = HeiMaTouTiao()
    heimaitaotiao.run()
