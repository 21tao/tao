from selenium import webdriver  # 模拟用户操作浏览器
import time
import json
# 用于显示等待
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By


# 抓取动态网页
# 定义url类
class JiXinDa:
    def __init__(self):
        self.url = 'http://jxd.itheima.net/#/login'
        self.driver = webdriver.Chrome()

    #     操作页面方法
    def login_to_find(self):
        # 发送请求/窗口最大化
        self.driver.get(self.url)
        self.driver.maximize_window()
        # 单击登陆
        self.driver.find_element_by_class_name('login-btn').click()
        #  单击体验项目
        self.driver.find_element_by_class_name('button').click()
        #  单击短信服务和服务日志
        self.driver.find_element_by_xpath('//div[contains(@class,"sider-bar") and contains('
                                          '@class,"scole-bar")]/ul/li['
                                          '2]/div/div/span').click()
        # webdriver.ActionChains(self.driver).move_to_element(sms_service_element).click(
        # sms_service_element).perform() sms_service_element =

        # self.driver.find_element_by_xpath('//div[contains(@class,"sider-bar") and contains('
        #                                   '@class,"scole-bar")]/ul/li['
        #                                   '2]/ul/li/ul/li[5]').click()
        time.sleep(2)
        self.driver.find_element_by_xpath('//*[@id="app"]/div/div[1]/ul/li[2]/ul/li/ul/li[5]').click()
        # webdriver.ActionChains(self.driver).move_to_element(service_log).click(service_log).perform()  service_log =
        # 显示等待input加载
        WebDriverWait(self.driver, 20).until(
            EC.presence_of_element_located((By.XPATH,
                                            '//*[@id="app"]/div/div[2]/div[1]/div/div/div/div/div[3]/div['
                                            '1]/form/div/div[1]/div/div/div/input'))
        )
        #  输入框输入签名名称应用名称
        self.driver.find_element_by_xpath(
            '//*[@id="app"]/div/div[2]/div[1]/div/div/div/div/div[3]/div[1]/form/div/div[1]/div/div/div/input').send_keys(
            '黑马头条')
        # 显示等待input加载
        WebDriverWait(self.driver, 20).until(
            EC.presence_of_element_located((By.XPATH,
                                            '//*[@id="app"]/div/div[2]/div[1]/div/div/div/div/div[3]/div['
                                            '1]/form/div/div[5]/div/div/div/button[1]'))
        )
        self.driver.find_element_by_xpath(
            '//*[@id="app"]/div/div[2]/div[1]/div/div/div/div/div[3]/div[1]/form/div/div[4]/div/div/div/input').send_keys(
            '黑马头条')
        #         搜索
        # 显示等待
        WebDriverWait(self.driver, 20).until(
            EC.presence_of_element_located((By.XPATH,
                                            '//*[@id="app"]/div/div[2]/div[1]/div/div/div/div/div[3]/div['
                                            '1]/form/div/div[5]/div/div/div/button[1] '
                                            ))
        )
        # 单击搜索
        self.driver.find_element_by_xpath(
            '//*[@id="app"]/div/div[2]/div[1]/div/div/div/div/div[3]/div[1]/form/div/div[5]/div/div/div/button[1]').click()

    # 获取目标数据
    def get_data(self):
        title_li = []
        # 遍历各类标题，如序号，创建名称
        for i in range(1, 9):
            title = self.driver.find_element_by_xpath('//*[@id="app"]/div/div[2]/div[1]/div/div/div/div/div[3]/div['
                                                      f'2]/div[1]/div[2]/table/thead/tr/th[{i}]').text
            title_li.append(title)
        content_info = []
        # 获取日志信息的所有行的个数
        num = self.driver.find_elements_by_xpath(
            '//*[@id="app"]/div/div[2]/div[1]/div/div/div/div/div[3]/div[2]/div[1]/div[3]/table/tbody/tr'

        )
        # 遍历获取每一行的信息，并转化字典，content.splitlines()除去换行符
        for i in range(1, len(num) + 1):
            content = self.driver.find_element_by_xpath(
                f'//*[@id="app"]/div/div[2]/div[1]/div/div/div/div/div[3]/div[2]/div[1]/div[3]/table/tbody/tr[{i}]'

            ).text
            content_info.append(dict(zip(title_li, content.splitlines())))
        return content_info

    #     保存数据
    def save_data(self, data):
        try:
            with open('jixinda.json', mode='a+', encoding='utf-8') as file:
                # 将字典数据抓为json,并保存
                file.write(json.dumps(data, ensure_ascii=False))
                file.write('\n')
        except Exception as e:
            print(e)
        return False

    #     启动
    def run(self):
        self.login_to_find()
        num = 1
        while True:
            button = self.driver.find_element_by_xpath(
                '//*[@id="app"]/div/div[2]/div[1]/div/div/div/div/div[3]/div[2]/div[2]/button[2]'
            )
            # 判断下一页的按钮是否可以用，如果可以，则单击下1、一页
            if button.is_enabled():
                data = self.get_data()
                self.save_data(data)
                print(f'正在保存{num}数据')
                print(data)
                num += 1
                button.click()
            else:
                end_data = self.get_data()
                print(f'正在保存{num}数据')
                self.save_data(end_data)
                self.driver.close()
                break


if __name__ == '__main__':
    jixinda = JiXinDa()
    jixinda.run()
