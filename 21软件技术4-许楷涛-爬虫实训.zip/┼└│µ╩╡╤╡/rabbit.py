import requests
import json
from pymongo import MongoClient


class LittleRabbit:

    def __init__(self):
        # 第1个页面
        # 准备车载类页面的url
        self.init_url = 'https://apipc-xiaotuxian-front.itheima.net/category/goods/temporary'

        # 请求头
        self.headers = {
            "Content-Type": "application/json;charset=UTF-8",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
                          "Chrome/108.0.0.0 Safari/537.36 "
        }
        # 连接mongonDB的客户端
        self.client = MongoClient('127.0.0.1', 27017)
        # 抓取所有商品页面数据

    def load_catgory_page(self, page):
        # 第1个页面的请求体 Request PayLoa
        reques_payload = {"page": page, "pageSize": 20, "categoryId": "1020002"}

        #         将字典form_data转换为JSON数据字符串
        json_data = json.dumps(reques_payload)
        response = requests.post(url=self.init_url, data=json_data, headers=self.headers)

        #   temporary文件的数据，将服务器返回的json字符串先转换为字典，再获取字典的商品信息
        all_goods = json.loads(response.text)["result"]["items"]

        return all_goods

    # 抓取具体商品数据/第2个页面
    def load_detail_page(self, all_goods):
        # 获取到具体商品json数据
        base_url = "https://apipc-xiaotuxian-front.itheima.net/goods?"

        #         定义1个数组用于存储所有商品具体数据
        goods_detail_info = []
        # 获取请求，并将文件数据暂存数组
        for gooos_info in all_goods:
            good_id = dict(id=gooos_info['id'])

            response = requests.get(url=base_url, params=good_id)

            good_detail = json.loads(response.text)
            goods_detail_info.append(good_detail)

        return goods_detail_info

    # 解析商品数据
    def parse_page(self, detail_data):
        # 保存所有商品信息
        all_goods_info = []
        goods = ""
        # 用于该页面与该页面图片地址链接
        temp_url = 'http://erabbit.itheima.net/#/product'

        for info in detail_data:
            dict_data = dict()
            dict_data['商品名称'] = info['result']['name']
            dict_data['商品描述'] = info['result']['desc']
            dict_data['商品链接'] = temp_url + info['result']['id']
            dict_data['商品价格'] = info['result']['price']
            dict_data['商品图片'] = info['result']['mainPictures'][0]
            good_detail = info['result']['details']['properties']
            for info1 in good_detail:
                goods = info1['name'] + ':' + info1['value']
            dict_data['商品详情'] = goods
            all_goods_info.append(dict_data)

        return all_goods_info

    #     保存数据
    def save_data(self, goods_info):
        # 链接本地数据库
        client = self.client

        #  访问创建数据库
        db = client.rabbit
        try:
            for good in goods_info:
                db.little_rabbit.insert_one(good)

            print('保存成功')

            result = db.little_rabbit.find()
            for doc in result:
                print(doc)
        except Exception as error:
            print(error)

    # 控制执行流程
    def run(self):

        begin = int(input('开始'))
        end = int(input('结束'))
        if begin <= 0:
            print('从1开始')
        else:
            for page in range(begin, end + 1):
                print(f'正在抓取{page}页')
                all_goods = self.load_catgory_page(page)
                goods_detail = self.load_detail_page(all_goods)
                goods_info = self.parse_page(goods_detail)
                self.save_data(goods_info)


if __name__ == '__main__':
    lr = LittleRabbit()
    lr.run()
