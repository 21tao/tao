package shixun;
public class RecordNode {
	public int key; // �ؼ���
	public int getKey(){
		return key;
	}
	public void setKey(int key) {
		this.key =key;
	}
	public RecordNode() {
	}
	public RecordNode(int key) { // ���췽��1
				this.key = key;
	}
	public String toString() { // ����toString()����
	return "[" + key+ "]";
	}
}

