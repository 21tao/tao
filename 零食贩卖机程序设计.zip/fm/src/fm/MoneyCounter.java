package fm;
import java.util.Scanner;
public class MoneyCounter {
	public void Cal(int Price){
		System.out.println("请按规定投币");
		System.out.println("1元");
		 System.out.println("5元");
		 System.out.println("10元");
		 System.out.println("20元");
		 System.out.println("50元");
		System.out.println("请投币..."); //投入硬币
		Scanner in = new Scanner(System.in);
		int totalPay = in.nextInt();
		if(totalPay==Price) {
		  Equal();//调用Equal方法
		}
		else if(totalPay>Price) {
		 More(totalPay,Price); //调用More方法
		}
		else {
		 for(int i=0;totalPay<Price;i++){ //当投入金额小于饮品价格时，ᨀ示继续投币
		 Scanner input = new Scanner(System.in);
		 System.out.println("请继续投币...");
		 int everyPay = input.nextInt();
		 totalPay+=everyPay;
		 }
		 if(totalPay==Price) { //当再次投币出现投币金额=价格时，调用Equal方法
		Equal();
		 }
		 else{
			 More(totalPay,Price);  //当再次投币出现投币金额>价格时，调用More方法
		 }
		}
		 }
		 public void Equal() { //当投入硬币和价格相同时
			 int change;
			 change = 0;
			 System.out.println("请在出口找零食"+"零钱为"+change);
			 System.out.println("1元"+0+"张");
			 System.out.println("5元"+0+"张");
			 System.out.println("10元"+0+"张");
			 System.out.println("20元"+0+"张");
			 System.out.println("50元"+0+"张");
		 }
		 public void More(int Price,int totalPay){ //当投入硬币总数大于价格总数时
			 int change;
			 change =Price  -  totalPay;//找零的零钱
			 int fifty = change/50;//算出50有多少张
			 int five = change - fifty*50;//算出50之后剩余多少钱
			 int twenty = five/20;
			 int two = five-twenty*20;
			 int ten = two/10;
			 int ten1 = two - ten*10;
			 int five1 = ten1/5;
			 int five11 = ten1 - five1*5;
			 int one = five11; 
		        System.out.println("请在出口找零食,零钱为"+change);
			 System.out.println("1元"+one+"张");
			 System.out.println("5元"+five1+"张");
			 System.out.println("10元"+ten+"张");
			 System.out.println("20元"+twenty+"张");
			 System.out.println("50元"+fifty+"张");
		 }
			
}
