package fm;
public class Goods {
	private int id; //���
	private String name; //��Ʒ��
	private int price;  //�۸�
	private int num;//����
	public Goods(){}
	public Goods(int id,String name,int price,int num){
				this.id = id;
				this.name = name;
				 this.price = price;
				 this.num = num;
	}
	//������ʳ�˵�
	public String toString(){
			return id+"."+name+"\t"+price+"Ԫ"+"\t"+num+"��";
	}
	//getter��sett
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getprice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
}
