package fm;
public class Usee {
	//�洢ϵͳ�û���������
	private static final int size=100;
    private static Use[] gss=new Use[size];
    private static int UseIndex=0;
    static {
    	gss[UseIndex++] = new Use("admin",123456);
    	gss[UseIndex++] = new Use("admin1",12345);
    	gss[UseIndex++] = new Use("admin2",1234);
    }
    //�����ж��Ƿ��½�ɹ�
    public void five(String name,int word) {
  	  try {
  		  boolean flge = true;
  	  for(int i=0;i<gss.length&&flge;i++) {
  		  
  		  if(gss[i].getPassWord()==word){
                System.out.println("��ӭ"+gss[i].getPassName()+"��½�ɹ�");
                flge = false;
  	  }
    }
} catch (Exception e) {
	  e.printStackTrace();
      System.out.println("��������");
  }
    }


	//�������
public void six(int word,int word1) {
	  try {
		  boolean flge = true;
	  for(int i=0;i<gss.length&&flge;i++) {
		  
		  if(gss[i].getPassWord()==word){
             gss[i] = new Use(gss[i].getPassName(),word1);
              flge = false;
	  }
  }
} catch (Exception e) {
	  e.printStackTrace();
    System.out.println("��������");
}
  }
}

