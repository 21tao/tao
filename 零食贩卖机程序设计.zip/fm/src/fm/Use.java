package fm;
public class Use {
	private int password; //������ 
	private String passname; //�û���
	public Use() {}
	public Use(String passname, int password) {
		this.passname = passname;
		this.password = password;
		// TODO �Զ����ɵĹ��캯�����
	}
	public String getPassName() {
		return passname;
	}
	public void setPassName(String passname) {
		this.passname = passname;
	}
	public int getPassWord() {
		return password;
	}
	public void setPassWord(int password) {
		this.password = password;
	}
}
